# JSON-Datatables

Once you downloaded the project, Extract it.

Make sure you have node and json-server installed on your system.
Download Node.JS: https://nodejs.org/en/download/
Install JSON-Server Module: npm i json-server

Now follow the steps below to run the application

1. Open up 3 seperate cmd(command window) and cd to the extracted folder.../JsonGrid on each window.
2. Run the below commands,one on each cmd window.
cmd1 - npm start
cmd2 - json-server --watch db.json
cmd3 - json-server -p 4000 --watch employees.json

Once the application has been started succesfully, run the url below on the browser

http://localhost:3004/test

 
Note:- This application uses 15 days trial version of dataTables.editor.js and dataTables.editor.min.js. You may download these files and replace it with the files in ..\Json-Grid\public\js

[Click here](https://www.youtube.com/watch?v=8jE2WUcjkQM) for video tutorial

Need a Panther Web 551 Redhat Image? [Click Here](https://hub.docker.com/r/prolificspanther)
Contact support@prolifics.com for a 45 day license included.
